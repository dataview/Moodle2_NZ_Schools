// JavaScript Document
function CheckAnswer(answer)
{
	switch(answer)
	{	
		case "answer1":
			    if ((document.getElementById('ab1').value == "6,8,1") && (document.getElementById('ab2').value == "3,2,4") && (document.getElementById('ab3').value == "7,4,5") && (document.getElementById('ab4').value == "5,3,1")){document.getElementById('fb1').value = "Correct !"} 
			  else if ((document.getElementById('ab1').value == "6, 8, 1") && (document.getElementById('ab2').value == "3, 2, 4") && (document.getElementById('ab3').value == "7, 4, 5") && (document.getElementById('ab4').value == "5, 3, 1")){document.getElementById('fb1').value = "Correct !"} 
			  
				else {document.getElementById('fb1').value = 'Incorrect !, Try again'}		
				
			break;
			
		
			
	}
	}