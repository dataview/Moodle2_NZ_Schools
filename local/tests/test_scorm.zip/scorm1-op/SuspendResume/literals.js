
function CheckAnswer1() {
 
    var feedback = document.getElementById('feedbackLayer1');
    
    if      (document.getElementById('q1Radio1').checked == true  ) 
            {feedback.innerHTML="<img src='Images/CorrectAnswer.gif'>";feedback.style.display = 'block'} 
    else if (document.getElementById('q1Radio2').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}  
    else if (document.getElementById('q1Radio3').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
	else if (document.getElementById('q1Radio4').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
    }

function CheckAnswer2() {
 
    var feedback = document.getElementById('feedbackLayer2');
    
    if      (document.getElementById('q2Radio1').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'} 
    else if (document.getElementById('q2Radio2').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}  
    else if (document.getElementById('q2Radio3').checked == true  ) 
            {feedback.innerHTML="<img src='Images/CorrectAnswer.gif'>";feedback.style.display = 'block'}
	else if (document.getElementById('q2Radio4').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
    }
    
function CheckAnswer3() {
 
    var feedback = document.getElementById('feedbackLayer3');
    
    if      (document.getElementById('q3Radio1').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'} 
    else if (document.getElementById('q3Radio2').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}  
    else if (document.getElementById('q3Radio3').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
	else if (document.getElementById('q3Radio4').checked == true  ) 
            {feedback.innerHTML="<img src='Images/CorrectAnswer.gif'>";feedback.style.display = 'block'}
    }
    
function CheckAnswer4() {
 
    var feedback = document.getElementById('feedbackLayer4');
    
    if      (document.getElementById('q4Radio1').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'} 
    else if (document.getElementById('q4Radio2').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}  
    else if (document.getElementById('q4Radio3').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
	else if (document.getElementById('q4Radio4').checked == true  ) 
            {feedback.innerHTML="<img src='Images/CorrectAnswer.gif'>";feedback.style.display = 'block'}
    }
    
function CheckAnswer5() {
 
    var feedback = document.getElementById('feedbackLayer5');
    
    if      (document.getElementById('q5Radio1').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'} 
    else if (document.getElementById('q5Radio2').checked == true  ) 
            {feedback.innerHTML="<img src='Images/CorrectAnswer.gif'>";feedback.style.display = 'block'}  
    else if (document.getElementById('q5Radio3').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
	else if (document.getElementById('q5Radio4').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
    }

function CheckAnswer6() {
 
    var feedback = document.getElementById('feedbackLayer6');
    
    if      (document.getElementById('q6Radio1').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'} 
    else if (document.getElementById('q6Radio2').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}  
    else if (document.getElementById('q6Radio3').checked == true  ) 
            {feedback.innerHTML="<img src='Images/CorrectAnswer.gif'>";feedback.style.display = 'block'}
	else if (document.getElementById('q6Radio4').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
    }
	
function CheckAnswer7() {
 
    var feedback = document.getElementById('feedbackLayer7');
    
    if      (document.getElementById('q7Radio1').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'} 
    else if (document.getElementById('q7Radio2').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}  
    else if (document.getElementById('q7Radio3').checked == true  ) 
            {feedback.innerHTML="<img src='Images/IncorrectAnswer.gif'>";feedback.style.display = 'block'}
	else if (document.getElementById('q7Radio4').checked == true  ) 
            {feedback.innerHTML="<img src='Images/CorrectAnswer.gif'>";feedback.style.display = 'block'}
    }